// main.cpp
#include <iostream>
#include "Counter.h"
using namespace std;

// define and initialize static data member at global namespace scope
unsigned int Counter::count{100}; // cannot include keyword static

unsigned int Counter::getCount(){ return count; }

int main() {
    cout << "Counter starts with " << Counter::getCount() << endl;
    {
        Counter c1;
        cout << "Counter after 'c1' created: " << Counter::getCount() << endl;
        {
            Counter c2;
            cout << "Counter after 'c2' created: " << Counter::getCount() << endl;
        }
        cout << "Counter after 'c2' destroyed: " << Counter::getCount() << endl;
    }
    cout << "Counter after 'c1' destroyed:  " << Counter::getCount() << endl;
}
