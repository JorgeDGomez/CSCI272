// Counter.h
#include <iostream>
using namespace std;

class Counter {
    static unsigned int count; // number of objects instantiated
public:
    Counter()  { cout << "new object created" << endl; ++count; };
    ~Counter() { cout << "object destroyed" << endl; --count; };
    static unsigned int getCount();
};